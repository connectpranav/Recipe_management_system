package com.example.recipe_management_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
