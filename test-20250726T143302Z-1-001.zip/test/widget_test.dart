import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import '../lib/main.dart';
import '../lib/providers/app_state.dart';

void main() {
  testWidgets('Login and navigate to Home Page', (WidgetTester tester) async {
    // Create the AppState with required parameters
    final appState = AppState(themeMode: ThemeMode.light, languageCode: 'en');

    // Load the main app widget with ChangeNotifierProvider for AppState
    await tester.pumpWidget(
      ChangeNotifierProvider.value(
        value: appState,
        child: RecipeApp(),
      ),
    );

    // Verify the login screen elements are present
    expect(find.text('Login'), findsOneWidget);
    expect(find.byKey(const Key('usernameField')), findsOneWidget);
    expect(find.byKey(const Key('passwordField')), findsOneWidget);

    // Simulate user input
    await tester.enterText(find.byKey(const Key('usernameField')), 'testuser');
    await tester.enterText(find.byKey(const Key('passwordField')), 'testpass');

    // Tap the login button
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pumpAndSettle();

    // Check if we are on the Home Page
    expect(find.textContaining('Welcome'), findsOneWidget);
    expect(find.text('My Cookbook'), findsOneWidget);
    expect(find.byIcon(Icons.home), findsOneWidget);
  });
}
