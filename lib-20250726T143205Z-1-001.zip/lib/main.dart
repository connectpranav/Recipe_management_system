import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:recipe_management_app/utils/shared_preferences_helper.dart'; // Corrected import for SharedPreferencesHelper
import 'providers/app_state.dart';
import 'pages/login_page.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'l10n/app_localizations.dart'; // Import the custom AppLocalizations file
import 'pages/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load theme mode and language code from shared preferences
  final themeModeString = await SharedPreferencesHelper.getThemeMode() ?? 'system';
  final languageCode = await SharedPreferencesHelper.getLanguageCode() ?? 'en';

  ThemeMode themeMode;
  switch (themeModeString) {
    case 'light':
      themeMode = ThemeMode.light;
      break;
    case 'dark':
      themeMode = ThemeMode.dark;
      break;
    default:
      themeMode = ThemeMode.system;
  }

  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(
        themeMode: themeMode,
        languageCode: languageCode,
      )..loadPreferences(),
      child: const RecipeApp(),
    ),
  );
}

class RecipeApp extends StatelessWidget {
  const RecipeApp({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return MaterialApp(
      title: 'My Cookbook',
      theme: _buildLightTheme(), // Improved light theme configuration
      darkTheme: _buildDarkTheme(), // Improved dark theme configuration
      themeMode: appState.themeMode, // Dynamically updates the theme mode
      locale: appState.locale, // Dynamically updates the locale
      supportedLocales: const [
        Locale('en'),
        Locale('hi'),
        Locale('mr'),
      ],
      localizationsDelegates: const [
        AppLocalizations.delegate, // Custom localization delegate
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      localeResolutionCallback: (locale, supportedLocales) {
        for (var supportedLocale in supportedLocales) {
          if (supportedLocale.languageCode == locale?.languageCode) {
            return supportedLocale;
          }
        }
        return supportedLocales.first; // Fallback to the first locale if no match is found
      },
      home: const LoginPage(), // The login page is the app's entry point
      debugShowCheckedModeBanner: false,
    );
  }

  // Separate methods for building light and dark themes
  ThemeData _buildLightTheme() {
    return ThemeData(
      primarySwatch: Colors.deepOrange,
      fontFamily: 'TimesNewRoman',
      scaffoldBackgroundColor: Colors.white,
      brightness: Brightness.light,
      visualDensity: VisualDensity.adaptivePlatformDensity,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        titleTextStyle: TextStyle(color: Colors.black, fontSize: 20),
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Colors.black), // Ensures large body text is black
        bodyMedium: TextStyle(color: Colors.black87), // Ensures medium body text is dark enough
        bodySmall: TextStyle(color: Colors.black54), // Smaller text is slightly lighter
        titleLarge: TextStyle(color: Colors.black), // Replaces headline6
        titleMedium: TextStyle(color: Colors.black), // Replaces subtitle1
      ),
    );
  }

  ThemeData _buildDarkTheme() {
    return ThemeData(
      primarySwatch: Colors.deepOrange,
      fontFamily: 'TimesNewRoman',
      scaffoldBackgroundColor: Colors.black,
      brightness: Brightness.dark,
      visualDensity: VisualDensity.adaptivePlatformDensity,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.white),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Colors.white), // Ensures large body text is white
        bodyMedium: TextStyle(color: Colors.white70), // Ensures medium body text is slightly grayed
        bodySmall: TextStyle(color: Colors.white54), // Smaller text is lighter
        titleLarge: TextStyle(color: Colors.white), // Replaces headline6
        titleMedium: TextStyle(color: Colors.white), // Replaces subtitle1
      ),
    );
  }
}