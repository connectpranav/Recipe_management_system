// scaling_helper.dart
double parseFraction(String input) {
  if (input.contains('/')) {
    final parts = input.split('/');
    if (parts.length == 2) {
      double numerator = double.tryParse(parts[0]) ?? 1.0;
      double denominator = double.tryParse(parts[1]) ?? 1.0;
      return numerator / denominator;
    }
  }
  return double.tryParse(input) ?? 1.0; // fallback for "1", "2.5", etc.
}

List<String> scaleIngredients(List<String> ingredients, String factorInput) {
  final double scaleFactor = parseFraction(factorInput);
  final RegExp regex = RegExp(r'^([\d\.]+)\s*([a-zA-Z]+)\s+(.+)$');

  return ingredients.map((item) {
    final match = regex.firstMatch(item);
    if (match != null) {
      double quantity = double.parse(match.group(1)!);
      String unit = match.group(2)!;
      String name = match.group(3)!;
      double scaled = quantity * scaleFactor;
      return '${scaled.toStringAsFixed(2)} $unit $name';
    } else {
      return item; // Unquantifiable items like "Salt to taste"
    }
  }).toList();
}
